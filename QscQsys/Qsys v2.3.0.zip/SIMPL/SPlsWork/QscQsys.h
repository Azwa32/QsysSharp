namespace QscQsys;
        // class declarations
         class QsysComponent;
         class QsysRoomCombiner;
         class QsysPotsController;
         class QsysSoftphoneController;
         class QsysCamera;
         class PtzTypes;
         class GetComponents;
         class ComponentResults;
         class ComponentProperties;
         class CreateChangeGroup;
         class CreateChangeGroupParams;
         class AddComoponentToChangeGroup;
         class AddControlToChangeGroup;
         class AddControlToChangeGroupParams;
         class AddComponentToChangeGroupParams;
         class Component;
         class Control;
         class ControlName;
         class Heartbeat;
         class HeartbeatParams;
         class ChangeResult;
         class ComponentChange;
         class ControlIntegerChange;
         class ControlStringChange;
         class ComponentChangeParams;
         class ControlIntegerParams;
         class ControlStringParams;
         class ComponentSetValue;
         class SetCrossPointMute;
         class SetCrossPointMuteParams;
         class ComponentChangeString;
         class ComponentChangeParamsString;
         class ComponentSetValueString;
         class ListBoxChoice;
         class Logon;
         class LogonParams;
         class QsysSignalPresence;
         class QsysSnapshot;
         class QsysInternalEventsArgs;
         class QsysCore;
         class QsysNv32hDecoder;
         class QsysMeter;
         class QsysNamedControl;
         class QsysMatrixMixer;
         class QsysRouter;
         class QsysFader;
         class QsysMatrixMixerCrosspoint;
     class QsysComponent 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , Component component );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysRoomCombiner 
    {
        // class delegates
        delegate FUNCTION WallStateChange ( SIMPLSHARPSTRING cName , INTEGER wall , INTEGER value );
        delegate FUNCTION RoomCombinedChange ( SIMPLSHARPSTRING cName , INTEGER room , INTEGER value );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName , SIGNED_LONG_INTEGER rooms , SIGNED_LONG_INTEGER walls );
        FUNCTION SetWall ( INTEGER wall , INTEGER value );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty WallStateChange onWallStateChange;
        DelegateProperty RoomCombinedChange onRoomCombinedChange;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysPotsController 
    {
        // class delegates
        delegate FUNCTION OffHookEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION RingingEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DialingEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION IncomingCallEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION AutoAnswerEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DndEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DialStringEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING dialString );
        delegate FUNCTION CurrentlyCallingEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING currentlyCalling );
        delegate FUNCTION CurrentCallStatus ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING callStatus );
        delegate FUNCTION RecentCallsEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING item1 , SIMPLSHARPSTRING item2 , SIMPLSHARPSTRING item3 , SIMPLSHARPSTRING item4 , SIMPLSHARPSTRING item5 );
        delegate FUNCTION RecentCallListEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING xsig );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION NumPad ( STRING number );
        FUNCTION NumString ( STRING number );
        FUNCTION NumPadDelete ();
        FUNCTION NumPadClear ();
        FUNCTION Dial ();
        FUNCTION Connect ();
        FUNCTION Disconnect ();
        FUNCTION Redial ();
        FUNCTION AutoAnswerToggle ();
        FUNCTION DndToggle ();
        FUNCTION SelectRecentCall ( SIGNED_LONG_INTEGER index );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty OffHookEvent onOffHookEvent;
        DelegateProperty RingingEvent onRingingEvent;
        DelegateProperty DialingEvent onDialingEvent;
        DelegateProperty IncomingCallEvent onIncomingCallEvent;
        DelegateProperty AutoAnswerEvent onAutoAnswerEvent;
        DelegateProperty DndEvent onDndEvent;
        DelegateProperty DialStringEvent onDialStringEvent;
        DelegateProperty CurrentlyCallingEvent onCurrentlyCallingEvent;
        DelegateProperty CurrentCallStatus onCurrentCallStatusChange;
        DelegateProperty RecentCallsEvent onRecentCallsEvent;
        DelegateProperty RecentCallListEvent onRecentCallListEvent;
        STRING DialString[];
        STRING CurrentlyCalling[];
        STRING LastNumberCalled[];
        STRING CallStatus[];
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysSoftphoneController 
    {
        // class delegates
        delegate FUNCTION OffHookEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION RingingEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DialingEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION IncomingCallEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION AutoAnswerEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DndEvent ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION DialStringEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING dialString );
        delegate FUNCTION CurrentlyCallingEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING currentlyCalling );
        delegate FUNCTION CurrentCallStatus ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING callStatus );
        delegate FUNCTION RecentCallsEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING item1 , SIMPLSHARPSTRING item2 , SIMPLSHARPSTRING item3 , SIMPLSHARPSTRING item4 , SIMPLSHARPSTRING item5 );
        delegate FUNCTION RecentCallListEvent ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING xsig );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION NumPad ( STRING number );
        FUNCTION NumString ( STRING number );
        FUNCTION NumPadDelete ();
        FUNCTION NumPadClear ();
        FUNCTION Dial ();
        FUNCTION Connect ();
        FUNCTION Disconnect ();
        FUNCTION Redial ();
        FUNCTION AutoAnswerToggle ();
        FUNCTION DndToggle ();
        FUNCTION SelectRecentCall ( SIGNED_LONG_INTEGER index );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty OffHookEvent onOffHookEvent;
        DelegateProperty RingingEvent onRingingEvent;
        DelegateProperty DialingEvent onDialingEvent;
        DelegateProperty IncomingCallEvent onIncomingCallEvent;
        DelegateProperty AutoAnswerEvent onAutoAnswerEvent;
        DelegateProperty DndEvent onDndEvent;
        DelegateProperty DialStringEvent onDialStringEvent;
        DelegateProperty CurrentlyCallingEvent onCurrentlyCallingEvent;
        DelegateProperty CurrentCallStatus onCurrentCallStatusChange;
        DelegateProperty RecentCallsEvent onRecentCallsEvent;
        DelegateProperty RecentCallListEvent onRecentCallListEvent;
        STRING DialString[];
        STRING CurrentlyCalling[];
        STRING LastNumberCalled[];
        STRING CallStatus[];
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysCamera 
    {
        // class delegates
        delegate FUNCTION PrivacyChange ( SIMPLSHARPSTRING _cName , INTEGER privacyValue );
        delegate FUNCTION BrightnessChange ( SIMPLSHARPSTRING _cName , INTEGER brightnessValue );
        delegate FUNCTION SaturationChange ( SIMPLSHARPSTRING _cName , INTEGER saturationValue );
        delegate FUNCTION SharpnessChange ( SIMPLSHARPSTRING _cName , INTEGER sharpnessValue );
        delegate FUNCTION ContrastChange ( SIMPLSHARPSTRING _cName , INTEGER contrastValue );
        delegate FUNCTION ExposureModeChange ( SIMPLSHARPSTRING _cName , SIMPLSHARPSTRING mode );
        delegate FUNCTION IrisChange ( SIMPLSHARPSTRING _cName , SIMPLSHARPSTRING irisValue );
        delegate FUNCTION ShutterChange ( SIMPLSHARPSTRING _cName , SIMPLSHARPSTRING apertureValue );
        delegate FUNCTION GainChange ( SIMPLSHARPSTRING _cName , INTEGER gainValue );
        delegate FUNCTION AutoWhiteBalanceSensitivityChange ( SIMPLSHARPSTRING _cName , SIMPLSHARPSTRING awbSens );
        delegate FUNCTION AutoWhiteBalanceModeChange ( SIMPLSHARPSTRING _cName , SIMPLSHARPSTRING awbMode );
        delegate FUNCTION WhiteBalanceHueChange ( SIMPLSHARPSTRING _cName , INTEGER hueValue );
        delegate FUNCTION WhiteBalanceRedGainChange ( SIMPLSHARPSTRING _cName , INTEGER redGainValue );
        delegate FUNCTION WhiteBalanceBlueGainChange ( SIMPLSHARPSTRING _cName , INTEGER blueGainValue );
        delegate FUNCTION AutoFocusChange ( SIMPLSHARPSTRING _cName , INTEGER value );

        // class events

        // class functions
        FUNCTION PanRight ();
        FUNCTION StopPanRight ();
        FUNCTION ZoomIn ();
        FUNCTION StopZoomIn ();
        FUNCTION ZoomOut ();
        FUNCTION StopZoomOut ();
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION StartPTZ ( PtzTypes type );
        FUNCTION StopPTZ ( PtzTypes type );
        FUNCTION AutoFocus ();
        FUNCTION FocusNear ();
        FUNCTION FocusNearStop ();
        FUNCTION FocusFar ();
        FUNCTION FocusFarStop ();
        FUNCTION RecallHome ();
        FUNCTION SaveHome ();
        FUNCTION PrivacyToggle ( INTEGER value );
        FUNCTION Brightness ( SIGNED_LONG_INTEGER value );
        FUNCTION Saturation ( SIGNED_LONG_INTEGER value );
        FUNCTION Sharpness ( SIGNED_LONG_INTEGER value );
        FUNCTION Contrast ( SIGNED_LONG_INTEGER value );
        FUNCTION ExposureMode ( STRING value );
        FUNCTION Iris ( STRING value );
        FUNCTION Shutter ( STRING value );
        FUNCTION Gain ( SIGNED_LONG_INTEGER value );
        FUNCTION AutoWhiteBalanceMode ( STRING value );
        FUNCTION AutoWhiteBalanceSensitivity ( STRING value );
        FUNCTION Hue ( SIGNED_LONG_INTEGER value );
        FUNCTION RedGain ( SIGNED_LONG_INTEGER value );
        FUNCTION BlueGain ( SIGNED_LONG_INTEGER value );
        FUNCTION TiltUp ();
        FUNCTION StopTiltUp ();
        FUNCTION TiltDown ();
        FUNCTION StopTiltDown ();
        FUNCTION PanLeft ();
        FUNCTION StopPanLeft ();
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty PrivacyChange onPrivacyChange;
        DelegateProperty BrightnessChange onBrightnessChange;
        DelegateProperty SaturationChange onSaturationChange;
        DelegateProperty SharpnessChange onSharpnessChange;
        DelegateProperty ContrastChange onContrastChange;
        DelegateProperty ExposureModeChange onExposureModeChange;
        DelegateProperty IrisChange onIrisChange;
        DelegateProperty ShutterChange onShutterChange;
        DelegateProperty GainChange onGainChange;
        DelegateProperty AutoWhiteBalanceSensitivityChange onAutoWhiteBalanceSensitivityChange;
        DelegateProperty AutoWhiteBalanceModeChange onAutoWhiteBalanceModeChange;
        DelegateProperty WhiteBalanceHueChange onWhiteBalanceHueChange;
        DelegateProperty WhiteBalanceRedGainChange onWhiteBalanceRedGainChange;
        DelegateProperty WhiteBalanceBlueGainChange onWhiteBalanceBlueGainChange;
        DelegateProperty AutoFocusChange onAutoFocusChange;
        INTEGER BrightnessValue;
        INTEGER SaturationValue;
        INTEGER SharpnessValue;
        INTEGER ContrastValue;
        STRING ExposureModeValue[];
        STRING IrisValue[];
        STRING ShutterValue[];
        INTEGER GainValue;
        STRING AutoWhiteBalanceSensitivityValue[];
        STRING AutoWhiteBalanceModeValue[];
        INTEGER HueValue;
        INTEGER RedGainValue;
        INTEGER BlueGainValue;
        INTEGER AutoFocusValue;
        STRING ComponentName[];
        STRING CoreID[];
    };

    static class PtzTypes // enum
    {
        static SIGNED_LONG_INTEGER Up;
        static SIGNED_LONG_INTEGER Down;
        static SIGNED_LONG_INTEGER Left;
        static SIGNED_LONG_INTEGER Right;
        static SIGNED_LONG_INTEGER ZoomIn;
        static SIGNED_LONG_INTEGER ZoomOut;
    };

     class GetComponents 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class ComponentResults 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
        STRING Type[];
    };

     class ComponentProperties 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
        STRING Value[];
    };

     class CreateChangeGroup 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class CreateChangeGroupParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class AddComoponentToChangeGroup 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING method[];
        AddComponentToChangeGroupParams ComponentParams;
    };

     class AddControlToChangeGroup 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING method[];
        AddControlToChangeGroupParams ControlParams;
    };

     class AddControlToChangeGroupParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class AddComponentToChangeGroupParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        Component Component;
    };

     class Component 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class Control 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class ControlName 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class Heartbeat 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        static STRING jsonrpc[];
        static STRING method[];

        // class properties
    };

     class HeartbeatParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class ChangeResult 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Component[];
        STRING Name[];
        STRING String[];
    };

     class ComponentChange 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        ComponentChangeParams Params;
    };

     class ControlIntegerChange 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        ControlIntegerParams Params;
    };

     class ControlStringChange 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        ControlStringParams Params;
    };

     class ComponentChangeParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class ControlIntegerParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class ControlStringParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
        STRING Value[];
    };

     class ComponentSetValue 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class SetCrossPointMute 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SetCrossPointMuteParams Params;
    };

     class SetCrossPointMuteParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
        STRING Inputs[];
        STRING Outputs[];
    };

     class ComponentChangeString 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        ComponentChangeParamsString Params;
    };

     class ComponentChangeParamsString 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
    };

     class ComponentSetValueString 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Name[];
        STRING Value[];
    };

     class ListBoxChoice 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Text[];
        STRING Color[];
        STRING Icon[];
    };

     class Logon 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        LogonParams Params;
    };

     class LogonParams 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING User[];
        STRING Password[];
    };

     class QsysSignalPresence 
    {
        // class delegates
        delegate FUNCTION SignalPresenceChange ( SIMPLSHARPSTRING cName , INTEGER index , INTEGER value );
        delegate FUNCTION PeakThresholdChange ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING value );
        delegate FUNCTION HoldTimeChange ( SIMPLSHARPSTRING cName , SIMPLSHARPSTRING value );
        delegate FUNCTION InfiniteHoldChange ( SIMPLSHARPSTRING cName , INTEGER value );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName , INTEGER count );
        FUNCTION ThresholdIncrement ();
        FUNCTION ThresholdDecrement ();
        FUNCTION HoldTimeIncrement ();
        FUNCTION HoldTimeDecrement ();
        FUNCTION InfiniteHold ( INTEGER value );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty SignalPresenceChange newSignalPresenceChange;
        DelegateProperty PeakThresholdChange newPeakThresholdChange;
        DelegateProperty HoldTimeChange newHoldTimeChange;
        DelegateProperty InfiniteHoldChange newInfiniteHoldChange;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysSnapshot 
    {
        // class delegates
        delegate FUNCTION RecalledSnapshot ( SIMPLSHARPSTRING cName , INTEGER snapshot );
        delegate FUNCTION UnrecalledSnapshot ( SIMPLSHARPSTRING cName , INTEGER snapshot );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION LoadSnapshot ( INTEGER number );
        FUNCTION SaveSnapshot ( INTEGER number );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty RecalledSnapshot onRecalledSnapshot;
        DelegateProperty UnrecalledSnapshot onUnrecalledSnapshot;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysCore 
    {
        // class delegates
        delegate FUNCTION IsLoggedIn ( SIMPLSHARPSTRING id , INTEGER value );
        delegate FUNCTION IsRegistered ( SIMPLSHARPSTRING id , INTEGER value );
        delegate FUNCTION IsConnectedStatus ( SIMPLSHARPSTRING id , INTEGER value );
        delegate FUNCTION CoreStatus ( SIMPLSHARPSTRING id , SIMPLSHARPSTRING designName , INTEGER isRedundant , INTEGER isEmulator );
        delegate FUNCTION SendingCommand ( SIMPLSHARPSTRING id , SIMPLSHARPSTRING command );

        // class events

        // class functions
        FUNCTION Debug ( INTEGER value );
        FUNCTION Initialize ( STRING id , STRING host , INTEGER port , STRING username , STRING password , INTEGER useExternalConnection );
        FUNCTION NewExternalResponse ( STRING response );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty IsLoggedIn onIsLoggedIn;
        DelegateProperty IsRegistered onIsRegistered;
        DelegateProperty IsConnectedStatus onIsConnected;
        DelegateProperty CoreStatus onNewCoreStatus;
        DelegateProperty SendingCommand onSendingCommand;
        INTEGER IsDebugMode;
        INTEGER MaxLogonAttemps;
        STRING DesignName[];
        STRING CoreId[];
    };

     class QsysNv32hDecoder 
    {
        // class delegates
        delegate FUNCTION Nv32hDecoderInputChange ( SIMPLSHARPSTRING cName , INTEGER input );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION ChangeInput ( SIGNED_LONG_INTEGER source );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty Nv32hDecoderInputChange newNv32hDecoderInputChange;
        STRING ComponentName[];
        SIGNED_LONG_INTEGER CurrentSource;
        STRING CoreID[];
    };

     class QsysMeter 
    {
        // class delegates
        delegate FUNCTION MeterChange ( SIMPLSHARPSTRING cName , INTEGER meterValue );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName , SIGNED_LONG_INTEGER meterIndex );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty MeterChange onMeterChange;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysNamedControl 
    {
        // class delegates
        delegate FUNCTION NamedControlChange ( SIMPLSHARPSTRING cName , INTEGER intData , SIMPLSHARPSTRING stringData );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING Name , INTEGER type );
        FUNCTION SetInteger ( SIGNED_LONG_INTEGER value , SIGNED_LONG_INTEGER scaled );
        FUNCTION SetString ( STRING value );
        FUNCTION SetBoolean ( SIGNED_LONG_INTEGER value );
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty NamedControlChange newNamedControlChange;
        STRING ComponentName[];
    };

     class QsysMatrixMixer 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING Name );
        FUNCTION SetCrossPointMute ( STRING inputs , STRING outputs , INTEGER value );
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class QsysRouter 
    {
        // class delegates
        delegate FUNCTION RouterInputChange ( SIMPLSHARPSTRING cName , INTEGER input );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName , SIGNED_LONG_INTEGER output );
        FUNCTION InputSelect ( SIGNED_LONG_INTEGER input );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty RouterInputChange newRouterInputChange;
        SIGNED_LONG_INTEGER CurrentSelectedInput;
        SIGNED_LONG_INTEGER Output;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysFader 
    {
        // class delegates
        delegate FUNCTION VolumeChange ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION MuteChange ( SIMPLSHARPSTRING cName , INTEGER value );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING componentName );
        FUNCTION Volume ( SIGNED_LONG_INTEGER value );
        FUNCTION Mute ( INTEGER value );
        FUNCTION Dispose ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty VolumeChange newVolumeChange;
        DelegateProperty MuteChange newMuteChange;
        SIGNED_LONG_INTEGER VolumeValue;
        STRING ComponentName[];
        STRING CoreID[];
    };

     class QsysMatrixMixerCrosspoint 
    {
        // class delegates
        delegate FUNCTION CrossPointValueChange ( SIMPLSHARPSTRING cName , INTEGER value );
        delegate FUNCTION CrossPointGainChange ( SIMPLSHARPSTRING cName , INTEGER value );

        // class events

        // class functions
        FUNCTION Initialize ( STRING coreId , STRING name , INTEGER input , INTEGER output );
        FUNCTION SetCrossPoint ( INTEGER value );
        FUNCTION SetCrossPointGain ( SIGNED_LONG_INTEGER value );
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty CrossPointValueChange newCrossPointValueChange;
        DelegateProperty CrossPointGainChange newCrossPointGainChange;
    };

